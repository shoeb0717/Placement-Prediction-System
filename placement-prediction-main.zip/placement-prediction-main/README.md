# placement-prediction
# deployed on heroku with Random Forest Model in the backend. Accuracy ~ 87%


URL - https://hashmi-waseem-placement-prediction-system-app-pndtof.streamlit.app/
